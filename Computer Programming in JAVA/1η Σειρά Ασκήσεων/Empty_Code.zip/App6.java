
/*
	Name: 
	Student Number:
*/

import java.util.Scanner;

class App6 {

		public static void main (String args []) {

		// Fill your code here
		
	}	
}
