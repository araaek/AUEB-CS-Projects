
/*
	Name: 
	Student Number:
*/


class App4 {
	
	// Fill your code here (Method)
	
	public static void main (String args[]){
		
		// Fill your code here 
		
	}
}