
/*
	Name: 
	Student Number:
*/

import java.io.*;

class App3 {
	
        public static void main(String args[]) throws IOException {
			
			// Fil your code here
			
        }
}