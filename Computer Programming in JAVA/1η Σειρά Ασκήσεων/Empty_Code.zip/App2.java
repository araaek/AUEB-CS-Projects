/*
	Name: 
	Student Number:
*/

import java.util.Scanner;

class App2 {
	
		
    // Fill your code here (Method)
		
  	
	public static void main(String args[]){
		
		// Fill your code here 
     	
   	}

}





