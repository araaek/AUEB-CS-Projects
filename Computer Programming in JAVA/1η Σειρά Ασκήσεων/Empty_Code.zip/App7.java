/*
	Name: 
	Student Number:
*/

import java.util.Scanner;

class product {
	
	// Fill your code here
	
}

class App7 {
	
	public static void main(String args[]){ 

		// Fill your code here
		
	}	
}