/*
	Name: 
	Student Number:
*/

import java.util.Scanner;

class calc {
	
	// Fill your code here
	
}

class App5 {		
  	
	public static void main(String args[]){
		
		// Fill your code here 
     	
   	}

}

